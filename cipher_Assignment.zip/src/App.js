import React from 'react';

import './App.css';
import Cipher from './components/ciphers';
import Selector from './components/selector'
function App() {
  return (
    <div className="App">
      <h1>Made By Mubashir Ali Baig</h1>
      <h2>Seat No# B16101075</h2>
      <h3>Section: A</h3>
      <Selector />
    </div>
  );
}

export default App;
